CREATE INDEX VehicleQuest 
ON Vehicles(vehicleState, color, year);